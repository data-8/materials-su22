test = {   'name': 'q2_2_5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> _framingham_sim1 = simulate_framingham_null()\n>>> _framingham_sim2 = simulate_framingham_null()\n>>> _framingham_sim1 != _framingham_sim2\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> _framingham_sim1 = simulate_framingham_null()\n'
                                               '>>> _framingham_sim2 = simulate_framingham_null()\n'
                                               '>>> _framingham_sim1 < framingham_observed_statistic and _framingham_sim2 < framingham_observed_statistic\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
