test = {   'name': 'q2_1_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(diabetes_test_statistic()) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(0)\n>>> np.isclose(round(diabetes_test_statistic(), 5) - 0.00189, 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
