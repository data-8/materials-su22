test = {   'name': 'q2_2_2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import hashlib\n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness"""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> \n'
                                               '>>> get_hash(ab_test_stat) # You chose the wrong test statistic.\n'
                                               "'c4ca4238a0b923820dcc509a6f75849b'",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
