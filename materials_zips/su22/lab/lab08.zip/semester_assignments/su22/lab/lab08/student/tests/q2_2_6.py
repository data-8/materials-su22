test = {   'name': 'q2_2_6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(framingham_simulated_stats) > 99\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(framingham_simulated_stats) == 500\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(np.average(framingham_simulated_stats)) <= 0.3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
