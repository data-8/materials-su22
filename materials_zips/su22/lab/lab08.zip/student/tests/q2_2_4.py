test = {   'name': 'q2_2_4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(framingham_test_statistic(framingham), (float, int, np.integer))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(round(framingham_observed_statistic, 3), 16.636)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
