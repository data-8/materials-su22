test = {   'name': 'q2_2_8',
    'points': None,
    'suites': [{'cases': [{'code': '>>> 0.0 <= framingham_p_val <= 0.05\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
