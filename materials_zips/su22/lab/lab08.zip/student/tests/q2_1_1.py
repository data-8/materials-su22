test = {   'name': 'q2_1_1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> 0 <= observed_diabetes_distance <= 0.02\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
