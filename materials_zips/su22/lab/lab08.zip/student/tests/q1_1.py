test = {   'name': 'q1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(unique_causes) in [np.ndarray, list]\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> sorted(unique_causes)[1] == 'Cancer'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
