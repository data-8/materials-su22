test = {   'name': 'q2_1_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(diabetes_simulated_stats) == 5000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(np.unique(diabetes_simulated_stats)) > 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
