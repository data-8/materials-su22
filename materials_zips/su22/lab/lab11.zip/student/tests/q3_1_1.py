test = {   'name': 'q3_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> sum(cancer.column(1)) == 9712\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum(cancer.column(2)) == 288\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> cancer\nstatus    | negative | positive\ncancer    | 10       | 90\nno cancer | 9702     | 198', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
