test = {   'name': 'q2_0_2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import hashlib \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> \n'
                                               '>>> get_hash(np.round(probability_shiny, 3))\n'
                                               "'a83a7d5356406fb9bdbb4d93697cee38'",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
