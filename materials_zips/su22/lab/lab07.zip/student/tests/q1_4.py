test = {   'name': 'q1_4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> round(height_mean, 3) == 64.049\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(height_sd, 3) == 2.525\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
