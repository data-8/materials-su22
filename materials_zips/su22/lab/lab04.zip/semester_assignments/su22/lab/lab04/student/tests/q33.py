test = {   'name': 'q33',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> import math\n>>> math.isclose(average_total_pay, 11558613.861386139, rel_tol = 0.1)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
