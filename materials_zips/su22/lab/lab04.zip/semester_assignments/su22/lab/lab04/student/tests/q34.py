test = {   'name': 'q34',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(cash_proportion) == 101\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import math\n>>> math.isclose(cash_proportion.item(0), 0.01784038, rel_tol = .001)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
