test = {   'name': 'q15',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 2 < number_wow_reactions < 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Incorrect value for number_wow_reactions\n>>> number_wow_reactions == 4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
