test = {   'name': 'q111',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> string_to_remove\n'hi'", 'hidden': False, 'locked': False}, {'code': ">>> new_word\n'matchmaker'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
