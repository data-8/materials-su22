test = {   'name': 'q31',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(top_10_movies) == tables.Table\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> top_10_movies.select('Name', 'Rating')\n"
                                               'Name                                                     | Rating\n'
                                               'The Shawshank Redemption (1994)                          | 9.2\n'
                                               'The Godfather (1972)                                     | 9.2\n'
                                               'The Godfather: Part II (1974)                            | 9\n'
                                               'Pulp Fiction (1994)                                      | 8.9\n'
                                               "Schindler's List (1993)                                  | 8.9\n"
                                               'The Lord of the Rings: The Return of the King (2003)     | 8.9\n'
                                               '12 Angry Men (1957)                                      | 8.9\n'
                                               'The Dark Knight (2008)                                   | 8.9\n'
                                               'Il buono, il brutto, il cattivo (1966)                   | 8.9\n'
                                               'The Lord of the Rings: The Fellowship of the Ring (2001) | 8.8',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
