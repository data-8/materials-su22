test = {   'name': 'q41',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> # Oops, your name is assigned to the wrong data type!\n'
                                               '>>> import numpy as np\n'
                                               '>>> type(year_population_crossed_6_billion) == int or type(year_population_crossed_6_billion) == np.int64\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> year_population_crossed_6_billion == 1999\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
