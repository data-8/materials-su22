test = {   'name': 'q1_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 0 <= expected_proportion_correct <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> expected_proportion_correct == 0.5\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
