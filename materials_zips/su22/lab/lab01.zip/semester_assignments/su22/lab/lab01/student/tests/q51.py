test = {   'name': 'q51',
    'points': None,
    'suites': [{'cases': [{'code': '>>> round(genghis_distance_from_average_in, 3)\n1.5', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
