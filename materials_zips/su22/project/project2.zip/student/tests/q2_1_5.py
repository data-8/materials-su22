test = {   'name': 'q2_1_5',
    'points': [3],
    'suites': [   {   'cases': [{'code': ">>> [most_common('Genre', close_movies.take(range(k))) for k in range(1, 6, 2)]\n['thriller', 'thriller', 'thriller']", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
