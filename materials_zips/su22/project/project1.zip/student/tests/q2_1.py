test = {   'name': 'q2_1',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': ">>> # Please don't edit the last line.\n>>> latest_poverty.labels == ('geo', 'time', 'poverty_percent')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> # The result should have one row per country.\n>>> latest_poverty.num_rows\n145', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
